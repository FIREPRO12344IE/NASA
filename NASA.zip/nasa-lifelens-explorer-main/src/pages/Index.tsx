import { DashboardPage } from './DashboardPage';

const Index = () => {
  return <DashboardPage />;
};

export default Index;
