import { useState } from 'react';
import { Header } from '@/components/Header';
import { Sidebar } from '@/components/Sidebar';
import { Dashboard } from '@/components/Dashboard';
import { Footer } from '@/components/Footer';
import { WelcomeAnimation } from '@/components/WelcomeAnimation';
import { FilterState } from '@/types/dashboard';
import { sampleResearchPapers } from '@/data/sampleData';

export function DashboardPage() {
  const [showWelcome, setShowWelcome] = useState(true);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [filters, setFilters] = useState<FilterState>({
    organismType: [],
    experimentType: [],
    yearRange: [2010, 2025],
    mission: [],
    searchQuery: ''
  });

  const handleSearchChange = (query: string) => {
    setFilters(prev => ({ ...prev, searchQuery: query }));
  };

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  if (showWelcome) {
    return <WelcomeAnimation onAnimationComplete={() => setShowWelcome(false)} />;
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header 
        onSearchChange={handleSearchChange}
        searchQuery={filters.searchQuery}
        onMenuToggle={toggleSidebar}
      />
      
      <div className="flex flex-1 relative">
        <Sidebar 
          filters={filters}
          onFiltersChange={setFilters}
          isOpen={isSidebarOpen}
          onClose={() => setIsSidebarOpen(false)}
        />
        
        <main className="flex-1 overflow-auto">
          <Dashboard 
            papers={sampleResearchPapers}
            filters={filters}
          />
        </main>
      </div>
      
      <Footer />
    </div>
  );
}